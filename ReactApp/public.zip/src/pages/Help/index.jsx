import React from "react";
import Navbar from "../../components/Navbar";
import "../../index.css";
function index() {
  return (
    <> 
      <h1>Help</h1>
      <h2>Vite + React + TS (Hamburger + Responsive + Router)</h2>
    </>
  );
}

export default index;
